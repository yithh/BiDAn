# Assignment II: Prediksi Permintaan Taksi Kuning NYC dengan Machine Learning dan Graph Analytics

Isi paket ini:

| File | Fungsi |
|---|---|---|
| `01_prepare_data.py` | Bersihkan dan ringkas data TLC (aturan R1–R7), tambah bulan, tambah cuaca
| `02_ml_sklearn.py` | Pipeline ML **tanpa Spark** (pandas + scikit-learn)
| `03_ml_spark.py` | Pipeline ML **dengan Spark MLlib** (fitur, pembagian data, dan model setara)
| `04_graph_analytics.py` | Graph analytics antar-zona (PageRank, betweenness, Louvain)
| `05_compare_results.py` | Tabel perbandingan akurasi dan waktu: tanpa Spark vs Spark 
| `run_all.py` | Menjalankan 01 sampai 05 berurutan
| `app.py` (+ `pipeline.py`, `analysis.py`) | Dasbor Streamlit: pola waktu, prediksi, keputusan bisnis berbasis ambang, graph, tambah data
| `data/` | Data Januari 2025 yang sudah diringkas, cuaca, dan lookup zona |

## A. Persiapan (sekali saja)
1. Pasang Python 3.10 atau lebih baru. Buka terminal di folder ini.
2. (Disarankan) virtual environment:
   - `python -m venv .venv`
   - Windows: `.venv\Scripts\activate`    Mac/Linux: `source .venv/bin/activate`
3. `pip install -r requirements.txt`
4. **Untuk langkah Spark saja:** pasang Java 17 (cek dengan `java -version`), lalu `pip install -r requirements-spark.txt`.
   - Python 3.10–3.11 memakai pyspark 3.5.x. Python 3.12 ke atas memakai pyspark 4.x. Biarkan pip memilih.
   - Windows: bila muncul peringatan `winutils` atau `HADOOP_HOME`, abaikan. Skrip ini hanya membaca CSV.
   - Bila memori kurang: `set SPARK_DRIVER_MEMORY=2g` (Windows) atau `export SPARK_DRIVER_MEMORY=2g` (Mac/Linux).

## B. Urutan menjalankan
Data Januari 2025 sudah ada, jadi langkah 1 boleh dilewati.

1. **(Opsional) Data baru.**
   - `python 01_prepare_data.py` untuk melihat data yang ada.
   - `python 01_prepare_data.py --parquet yellow_tripdata_2025-02.parquet` untuk file yang sudah kamu unduh.
   - `python 01_prepare_data.py --download 2025 1 2 3` untuk mengunduh Januari sampai Maret 2025 dari TLC (butuh internet, ±50–70 MB per bulan).
   - `python 01_prepare_data.py --weather weather_2025-02.csv` untuk cuaca IEM.
2. **Tanpa Spark:** `python 02_ml_sklearn.py`
   - Hasil: `results/sklearn_k60.json`.
3. **Dengan Spark MLlib:** `python 03_ml_spark.py`
   - Hasil: `results/spark_k60.json`. Pakai opsi yang sama dengan langkah 2.
   - Pertama kali jalan butuh sekitar satu menit untuk memulai Spark.
4. **Graph:** `python 04_graph_analytics.py`
   - Hasil: `results/graph_*.csv`, `graph_summary.json`, dan dua gambar `fig_graph_*.png`.
5. **Bandingkan:** `python 05_compare_results.py`
   - Hasil: `results/comparison.csv` (akurasi) dan `comparison_time.csv` (waktu).
6. **Dasbor:** `streamlit run app.py`, lalu buka http://localhost:8501.

Atau langkah 2–5 sekaligus: `python run_all.py` (Spark dilewati otomatis bila Java atau pyspark tidak ada; `--no-spark` untuk melewatinya).

## C. Percobaan skala (supaya perbandingan Spark berarti)
Dengan satu bulan dan 60 zona (±35 ribu baris), Spark lazimnya **lebih lambat** daripada scikit-learn karena ada biaya memulai Spark. Ini wajar. Naikkan ukuran data lalu bandingkan lagi:

```
python 01_prepare_data.py --download 2025 1 2 3 4 5 6      # tambah bulan
python 02_ml_sklearn.py --top-k 60            # percobaan k60
python 03_ml_spark.py   --top-k 60
python 02_ml_sklearn.py --top-k 250 --tag k250   # lebih banyak zona
python 03_ml_spark.py   --top-k 250 --tag k250
python 05_compare_results.py
```
Tiap percobaan punya `--tag` sendiri, jadi hasilnya tidak saling menimpa. Perbandingan waktu pada ukuran data kecil jangan dibaca sebagai bukti Spark lambat secara umum, dan sebaliknya.


## D. Catatan
- Fitur: kalender (jam, hari, akhir pekan, libur AS), riwayat (1 jam, 24 jam, 168 jam lalu, rata-rata 3 dan 24 jam), kebijakan (congestion pricing mulai 5 Jan 2025), dan cuaca (opsional). Semuanya hanya memakai informasi dari jam-jam sebelumnya.
- Data dibagi berdasarkan waktu: 7 hari terakhir untuk uji, sisanya untuk latih.
- Mesin Spark berjalan di komputermu sendiri (`local[*]`), bukan klaster. Ini menunjukkan alur MLlib, bukan kecepatan klaster sungguhan.
- Zona kecil sulit ditebak (galat relatifnya besar). Pada satu bulan data, cuaca tidak menambah akurasi.
